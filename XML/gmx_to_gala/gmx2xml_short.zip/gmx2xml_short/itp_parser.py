import re
from sys import argv

def itp_parser(fn):
    data = open(fn, 'r').read()
    lines = data.split('\n')
    imp_idx = -1
    pairs_idx = -1
    system_idx = -1
    molecule_idx = -1
    for i,l in enumerate(lines):
        if l == '[ atomtypes ]':
            atypes_idx = i
        if l == '[ moleculetype ]':
            moltype_idx = i
        if l == '[ atoms ]':
            atoms_idx = i
        if l == '[ bonds ]':
            bonds_idx = i
        if l == '[ angles ]':
            angles_idx = i
        if l == '[ dihedrals ]':
            if 'IMPROPER' in lines[i+1]:
               imp_idx = i
            else:
               dis_idx = i
        if l == '[ pairs ]':
            pairs_idx = i
        if l == '[ system ]':
            system_idx = i
        if l == '[ molecules ]':
            molecule_idx = i
    if system_idx == -1:
        system_idx = molecule_idx
    if pairs_idx == -1:
        pairs_idx = system_idx
    if imp_idx == -1:
        imp_idx = pairs_idx
    ## atom types
    atom_types = {}
    #res = re.findall(r'opls_\d+\s+[A-Za-z]+.*\d+.*', data)
    res = lines[atypes_idx:moltype_idx]
    for l in res:
        if l == '':
            continue
        line = re.split('\s', l.strip())
        while '' in line:
            line.remove('')
        if ('[' in l) or (';' in l):
            continue
        atom_types[line[0]] = (float(line[-2]), float(line[-1]), line[1], float(line[2]), str(line[-3]))
        #  sigma, epsilon, bondtype, mass, Ptype
    ret = {}
    #lines = data.split('\n')
    ## atom
    #res = re.findall(r'\s+\d+\s+opls_\d+\s+\d+.*', data)
    res = lines[atoms_idx:bonds_idx]
    #print(res)
    for l in res:
        if l == '':
            continue
        line = re.split('\s', l.strip())
        while '' in line:
            line.remove('')
        if ('[' in l) or (';' in l):
            continue
        atom_id = int(line[0]) - 1
        if ret.get(atom_id) is None:
            ret[atom_id] = {}
        charge = float(line[-2])
        sigma = atom_types[line[1]][0]
        epsilon = atom_types[line[1]][1]
        Ptype = atom_types[line[1]][-1]
        bond_type = atom_types[line[1]][2]
        ret[atom_id] = (bond_type, charge, sigma, epsilon,Ptype, 'atom')
    ## bond
    #res = re.findall(r'\n\s+\d+\s+\d+\s+\d+\s+\d+\.\d+\s+\d+\.\d+',data)
    res = lines[bonds_idx:angles_idx]
    for l in res:
        line = re.split('\s', l.strip())
        while '' in line:
            line.remove('')
        if ('[' in l) or (';' in l):
            continue
        if len(line) == 0:
            continue
        ai = int(line[0]) -1
        aj = int(line[1]) -1
        if ret.get((ai,aj)) is None:
            ret[(ai,aj)] = {}
        funct = int(line[2])
        r0 = float(line[3])
        k0 = float(line[4])
        ret[(ai,aj)] = (funct,r0,k0,'bond')
    ## angle
    #res = re.findall(r'\s+\d+\s+\d+\s+\d+\s+\d+\s+\d+\.\d+\s+\d+\.\d+\n',data)
    res = lines[angles_idx:dis_idx]
    for l in res:
        line = re.split('\s', l.strip())
        while '' in line:
            line.remove('')
        if ('[' in l) or (';' in l):
            continue
        if len(line) == 0:
            continue
        ai = int(line[0]) -1
        aj = int(line[1]) -1
        ak = int(line[2]) -1
        if ret.get((ai,aj,ak)) is None:
            ret[(ai,aj,ak)] = {}
        funct = int(line[3])
        th0 = float(line[4])
        k0 = float(line[5])
        ret[(ai,aj,ak)] = (funct,th0,k0,'angle')
    ## dihedral
    #res = re.findall(r'\n\s+\d+ \s+\d+ \s+\d+ \s+\d+ \s+[123] \s+.*',data)
    res = lines[dis_idx:imp_idx]
    for l in res:
        line = re.split('\s', l.strip())
        while '' in line:
            line.remove('')
        if ('[' in l) or (';' in l):
            continue
        if len(line) == 0:
            continue
        ai = int(line[0]) -1
        aj = int(line[1]) -1
        ak = int(line[2]) -1
        al = int(line[3]) -1
        if ret.get((ai,aj,ak,al)) is None:
            ret[(ai,aj,ak,al)] = {}
        funct = int(line[4])
        c0 = float(line[5])
        c1 = float(line[6])
        c2 = float(line[7])
        #c3 = float(line[8])
        #c4 = float(line[9])
        #c5 = float(line[10])
        ret[(ai,aj,ak,al)] = (funct,c0,c1,c2,'dihedral')
    ## improper
    #res = re.findall(r'\s+\d+\s+\d+\s+\d+\s+\d+\s+4\s+\d+\.\d+\s+\d+\.\d+\s+\d+.*\n',data)
    res = lines[imp_idx:pairs_idx]
    for l in res:
        line = re.split('\s', l.strip())
        while '' in line:
            line.remove('')
        if ('[' in l) or (';' in l):
            continue
        if len(line) == 0:
            continue
        ai = int(line[0]) -1
        aj = int(line[1]) -1
        ak = int(line[2]) -1
        al = int(line[3]) -1
        if ret.get((ai,aj,ak,al)) is None:
            ret[(ai,aj,ak,al)] = {}
        funct = int(line[4])
        c0 = float(line[5])
        c1 = float(line[6])
        c2 = float(line[7])
        ret[(ai,aj,ak,al)] = (funct,c0,c1,c2,'improper') 
    return ret
    #testf = open('test_ff.txt','w')
    #for i in ret:
    #    #print(ret[i])
    #    if type(i) is not tuple: 
    #        i_ = (i,)
    #    else:
    #        i_ = i
    #    testf.write(' '.join([str(_) for _ in i_])+' '+' '.join([str(_) for _ in ret[i]])+'\n')
    #testf.close()

#itp_parser(argv[1])
